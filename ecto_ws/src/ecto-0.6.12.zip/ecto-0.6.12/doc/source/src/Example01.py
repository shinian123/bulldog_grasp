#!/usr/bin/python 

import ecto
from ecto.ecto_examples import Example01

ecell = Example01(value=17)
ecell.process()
