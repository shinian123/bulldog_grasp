Start with the tutorial.cpp, then progress in the following pattern t000.cpp, pyt000_*.py, t001.cpp, pyt001_*.py
