ecto_ros
========

These are common ecto bindings for the ROS (Robot Operating System).
