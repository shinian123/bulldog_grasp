ecto_geometry_msgs
==================

ROS ecto cells that deal with ``geometry_msgs`` messages.

.. ectomodule:: ecto_ros.ecto_geometry_msgs
