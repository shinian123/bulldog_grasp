ecto_nav_msgs
=============

ROS ecto cells that deal with ``nav_msgs`` messages.

.. ectomodule:: ecto_ros.ecto_nav_msgs
