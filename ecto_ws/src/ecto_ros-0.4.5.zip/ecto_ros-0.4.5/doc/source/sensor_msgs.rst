ecto_sensor_msgs
================

ROS ecto cells that deal with ``sensor_msgs`` messages.

.. ectomodule:: ecto_ros.ecto_sensor_msgs
