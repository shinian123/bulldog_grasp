ecto_std_msgs
=============

General purpose ROS ecto cells

.. ectomodule:: ecto_ros.ecto_std_msgs
