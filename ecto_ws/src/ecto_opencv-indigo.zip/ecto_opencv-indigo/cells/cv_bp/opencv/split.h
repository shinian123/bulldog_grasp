#pragma once
namespace opencv_wrappers
{
  void wrap_cv_core();
  void wrap_mat();
  void wrap_points();
  void wrap_highgui();
}
