//These are all opencv type defines...
opencv.attr("CV_8U") = CV_8U;
opencv.attr("CV_8S") = CV_8S;
opencv.attr("CV_16U") = CV_16U;
opencv.attr("CV_16S") = CV_16S;
opencv.attr("CV_32S") = CV_32S;
opencv.attr("CV_32F") = CV_32F;
opencv.attr("CV_64F") = CV_64F;

opencv.attr("CV_8UC1") = CV_8UC1;
opencv.attr("CV_8UC2") = CV_8UC2;
opencv.attr("CV_8UC3") = CV_8UC3;
opencv.attr("CV_8UC4") = CV_8UC4;

opencv.attr("CV_8SC1") = CV_8SC1;
opencv.attr("CV_8SC2") = CV_8SC2;
opencv.attr("CV_8SC3") = CV_8SC3;
opencv.attr("CV_8SC4") = CV_8SC4;

opencv.attr("CV_16UC1") = CV_16UC1;
opencv.attr("CV_16UC2") = CV_16UC2;
opencv.attr("CV_16UC3") = CV_16UC3;
opencv.attr("CV_16UC4") = CV_16UC4;

opencv.attr("CV_16SC1") = CV_16SC1;
opencv.attr("CV_16SC2") = CV_16SC2;
opencv.attr("CV_16SC3") = CV_16SC3;
opencv.attr("CV_16SC4") = CV_16SC4;

opencv.attr("CV_32SC1") = CV_32SC1;
opencv.attr("CV_32SC2") = CV_32SC2;
opencv.attr("CV_32SC3") = CV_32SC3;
opencv.attr("CV_32SC4") = CV_32SC4;

opencv.attr("CV_32FC1") = CV_32FC1;
opencv.attr("CV_32FC2") = CV_32FC2;
opencv.attr("CV_32FC3") = CV_32FC3;
opencv.attr("CV_32FC4") = CV_32FC4;

opencv.attr("CV_64FC1") = CV_64FC1;
opencv.attr("CV_64FC2") = CV_64FC2;
opencv.attr("CV_64FC3") = CV_64FC3;
opencv.attr("CV_64FC4") = CV_64FC4;
