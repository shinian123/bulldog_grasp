#include <ecto/ecto.hpp>

ECTO_DEFINE_MODULE(features2d)
{

}
