.. _ecto_opencv:

ecto_opencv: Ecto OpenCV Wrappers
=================================

ecto opencv is a collection of ecto cells wrapping several OpenCV functionalities.

.. toctree::
   :maxdepth: 2
   
   samples/index.rst
   cells/index.rst
   conventions.rst
   writing_opencv_cells.rst

