Simple video capture
====================

Does video capture direct from the device, via opencv.  Uses the fps
cell to draw the framerate on the displayed image.  

Download: :download:`vidcap.py`

.. literalinclude:: vidcap.py

.. ectoplot::  vidcap.py plasm

