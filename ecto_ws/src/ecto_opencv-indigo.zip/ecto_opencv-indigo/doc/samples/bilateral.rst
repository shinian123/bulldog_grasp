Bilateral Filter Chain
======================

Chains together a bunch of Bilateral smoothing filters (http://homepages.inf.ed.ac.uk/rbf/CVonline/LOCAL_COPIES/MANDUCHI1/Bilateral_Filtering.html)
and runs them on a live video device.

Download: :download:`bilateral.py`

.. literalinclude:: bilateral.py

Produces output cartoonish output:

.. figure:: bilateral.png


.. ectoplot::  bilateral.py plasm

