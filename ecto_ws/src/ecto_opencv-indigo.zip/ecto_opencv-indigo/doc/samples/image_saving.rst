.. _sample-imshow-save:

Saving images
=============

Demonstration of saving images on a keystroke.

Download: :download:`image_saving.py`

.. literalinclude:: image_saving.py

.. ectoplot::  image_saving.py plasm

