.. _ecto_opencv.features2d:

ecto_opencv.features2d
----------------------

Feature detection cells.

.. ectomodule:: ecto_opencv.features2d

