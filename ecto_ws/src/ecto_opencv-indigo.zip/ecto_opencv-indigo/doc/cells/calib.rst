.. _ecto_opencv.calib:

ecto_opencv.calib
-----------------

The calib module contains cells that deal with camera calibration, fiducial pose
estimation, and structure from motion.

.. ectomodule:: ecto_opencv.calib
