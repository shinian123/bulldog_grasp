.. _ecto_opencv.imgproc:

ecto_opencv.imgproc
-------------------

image manipulation.

.. ectomodule:: ecto_opencv.imgproc

