#include <ecto/ecto.hpp>
ECTO_DEFINE_MODULE(opencv_test)
{
}
