#!/usr/bin/python

import ecto.ecto_examples as ecto_examples

cell = ecto_examples.EnumAsEnum(strategy=ecto_examples.ADAPTIVE)
cell.process()
