#!/usr/bin/python

import ecto.ecto_examples as ecto_examples

cell = ecto_examples.EnumAsInt(strategy=17)
cell.process()

