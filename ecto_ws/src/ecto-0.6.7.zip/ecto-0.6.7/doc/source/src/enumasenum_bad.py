#!/usr/bin/python

import ecto_examples

cell = ecto_examples.EnumAsEnum(strategy=17)
cell.process()
